# (c) adarsh-goel
